# (c) adarsh-goel
